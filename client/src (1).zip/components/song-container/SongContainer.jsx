import "./SongContainer.css"

const songs = [
  { id: 1, title: "Play It Safe", artist: "Julia Wolf", album: "Play It Safe", duration: "2:12" },
  { id: 2, title: "Ocean Front Apt.", artist: "ayokay", album: "In the Shape of a Dream", duration: "2:12" },
  { id: 3, title: "Free Spirit", artist: "Khalid", album: "Free Spirit", duration: "3:02" },
  { id: 4, title: "Remind You", artist: "FRENSHIP", album: "Vacation", duration: "4:25" },
  { id: 5, title: "Same Old", artist: "SHY Martin", album: "Same Old", duration: "2:56" },
  { id: 6, title: "Free Spirit", artist: "Khalid", album: "Free Spirit", duration: "3:02" },
  { id: 7, title: "Remind You", artist: "FRENSHIP", album: "Vacation", duration: "4:25" },
  { id: 8, title: "Same Old", artist: "SHY Martin", album: "Same Old", duration: "2:56" },
  { id: 9, title: "Free Spirit", artist: "Khalid", album: "Free Spirit", duration: "3:02" },
  { id: 10, title: "Remind You", artist: "FRENSHIP", album: "Vacation", duration: "4:25" },
  { id: 11, title: "Same Old", artist: "SHY Martin", album: "Same Old", duration: "2:56" },
  { id: 12, title: "Another Song", artist: "Artist Name", album: "Album Name", duration: "3:30" },
]

export function SongContainer() {
  return (
    <div className="song-container">
      <div className="table-responsive">
        <table className="table table-dark table-hover">
          <thead>
            <tr className="text-secondary">
              <th scope="col" width="5%">
                #
              </th>
              <th scope="col" width="45%">
                TITLE
              </th>
              <th scope="col" width="30%">
                ALBUM
              </th>
              <th scope="col" width="10%">
                DATE ADDED
              </th>
              <th scope="col" width="10%" className="text-end">
                ⏱️
              </th>
            </tr>
          </thead>
          <tbody>
            {songs.map((song) => (
              <tr key={song.id} className="song-item">
                <td>{song.id}</td>
                <td>
                  <div className="d-flex align-items-center gap-3">
                    <div className="bg-secondary rounded" style={{ width: "40px", height: "40px" }}>
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt={song.title}
                        className="w-100 h-100 object-fit-cover"
                      />
                    </div>
                    <div>
                      <div className="fw-medium">{song.title}</div>
                      <div className="small text-secondary">{song.artist}</div>
                    </div>
                  </div>
                </td>
                <td className="align-middle">{song.album}</td>
                <td className="align-middle small text-secondary">Today</td>
                <td className="align-middle text-end small text-secondary">{song.duration}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
