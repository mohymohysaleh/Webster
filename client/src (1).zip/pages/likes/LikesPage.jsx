import { Heart } from "lucide-react"
import { SongContainer } from "../../components/song-container/SongContainer"
import "./LikesPage.css"

export default function LikesPage() {
  return (
    <div className="p-0">
      {/* Header with gradient background */}
      <div className="likes-header p-4 pb-5 mb-4">
        <div className="d-flex align-items-end">
          <div className="likes-icon-container me-4">
            <Heart size={64} className="text-white" />
          </div>
          <div>
            <h1 className="display-4 fw-bold mb-2">Liked Songs</h1>
            <div className="d-flex align-items-center">
              <div className="bg-dark rounded-circle p-1 me-2" style={{ width: "24px", height: "24px" }}>
                <img src="/placeholder.svg?height=24&width=24" alt="Profile" className="w-100 h-100 rounded-circle" />
              </div>
              <span className="fw-medium me-2">KareemAdel</span>
              <span className="text-secondary small">• 34 songs</span>
            </div>
          </div>
        </div>
      </div>

      {/* Song list */}
      <div className="px-4">
        <SongContainer />
      </div>
    </div>
  )
}
